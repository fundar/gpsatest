<div style="min-height:400px;height:100%;margin-top:15px;">
<iframe id="buy_frame" src="<?php echo EDD_W3EDGE_STORE_URL_PLUGIN ?>" style="height:90%;width:100%" scrolling="auto">
</iframe>
</div>